package com.mapsa.StudentRegisteration.config.Annotations;

import org.springframework.context.annotation.Bean;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;

@Bean
@Documented
@Target({ElementType.METHOD,ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = SidValidationClass.class)
public @interface SidValidation {
    String message() default "Invalid student Id! ";
    Class<?>[] groups() default{};
    Class<? extends Payload> [] payload() default {};

}
