package com.mapsa.StudentRegisteration.config.Annotations;

import com.mapsa.StudentRegisteration.Model.StudentDto;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;



public class SidValidationClass implements ConstraintValidator<SidValidation, String> {

    @Override
    public void initialize(SidValidation constraintAnnotation) {
        //ConstraintValidator.super.initialize(constraintAnnotation);
    }

    @Override
    public boolean isValid(String s, ConstraintValidatorContext constraintValidatorContext) {



        if (s.length() != 8)          //length validation
           return false;
//
//        //get 4 first number of entrance date ex:"1997/02/03" --> "1997"
//        String entranceDateFirstFourDigits = studentDto.getEntranceDate()
//                .toString().substring(0, 4);
//
//        //first four number of student id ex:19970102 -->1997
//        String sidFirstFourDigits = s.substring(0, 4);
//
//        if (!(sidFirstFourDigits.equals(entranceDateFirstFourDigits)))  //entrance date comparison with sid
//            return false;
//
//        //separating digit 5  ex:19970102 -->0
//        String sidZeroDigit = s.substring(4, 5);         //zero digit validation; 5th digit must be zero
//
//        if (!(sidZeroDigit.equals("0")))
//            return false;
//
//        String sidGenderDigits = s.substring(5, 6);     //gender validation
//
//
//        if ((sidGenderDigits.equals("0")) &&            //5th character = 0 --> gender :male
//                (studentDto.getGender().equalsIgnoreCase("male")))
//            return true;
//        else if ((sidGenderDigits.equals("1")) &&       //5th character = 1 --> gender :female
//                (studentDto.getGender().equalsIgnoreCase("female")))
//            return true;
//        else
//            return false;                //only 5th character equal 0 and 1 is accepted
return true;
    }


}
