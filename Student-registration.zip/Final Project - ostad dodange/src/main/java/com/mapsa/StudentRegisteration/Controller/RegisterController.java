package com.mapsa.StudentRegisteration.Controller;

import com.mapsa.StudentRegisteration.Model.StudentDto;
import com.mapsa.StudentRegisteration.Service.FileUploadUtil;
import com.mapsa.StudentRegisteration.Service.StudentService;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.view.RedirectView;

import javax.validation.Valid;
import java.io.IOException;

@Controller
@RequiredArgsConstructor(onConstructor_ = @Autowired)
//@RequestMapping("/register")
public class RegisterController {

    private final StudentService studentService;

    @GetMapping(value = "/register")
    public String register(StudentDto studentDto) {

        return "Register";
    }


    @PostMapping("/register")
    public String submitForm(@ModelAttribute("studentDto") @Valid StudentDto studentDto,
                             BindingResult result,@RequestParam("image") MultipartFile multipartFile)
                             throws IOException{

        String fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
        studentDto.setPhotos(fileName);

        //save (everything from) studentdto's fields ; info and photo
        StudentDto savedStudent = studentService.save(studentDto);

        String uploadDir = "student-photos/" + savedStudent.getId();

        FileUploadUtil.saveFile(uploadDir, fileName, multipartFile);

        //studentService.save(studentDto);

        if (result.hasErrors()) {
            return "Error";
        }

        return "Register_success";
    }

}
