package com.mapsa.StudentRegisteration.Dao;

import com.mapsa.StudentRegisteration.Model.StudentDto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface StudentRepo extends JpaRepository<StudentDto,Long> {

}
