package com.mapsa.StudentRegisteration.Controller;

import com.mapsa.StudentRegisteration.Model.StudentDto;
import com.mapsa.StudentRegisteration.Service.StudentService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequiredArgsConstructor(onConstructor_ = @Autowired)
//@RequestMapping("/list")
public class ListOfStudentController {

    private final StudentService studentService;


    @GetMapping("/list")
    public String showStudentList(Model model) {
        model.addAttribute("studentDtoList", studentService.listOfStudent());
        return "ListOfStudent";
    }
}
