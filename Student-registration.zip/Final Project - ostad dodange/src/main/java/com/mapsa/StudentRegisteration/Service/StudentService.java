package com.mapsa.StudentRegisteration.Service;

import com.mapsa.StudentRegisteration.Model.StudentDto;
import org.springframework.stereotype.Service;
import com.mapsa.StudentRegisteration.Dao.StudentRepo;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class StudentService {

    private final StudentRepo studentRepo;

   public StudentService(StudentRepo studentRepo) {

        this.studentRepo = studentRepo;
    }

    public List <StudentDto> listOfStudent (){

        return studentRepo.findAll();
    }

    public StudentDto save(StudentDto StudentDto){

        studentRepo.save(StudentDto);

        return StudentDto;
    }

//    public void save (StudentDto StudentDto){
//
//        studentRepo.save(StudentDto);
//    }

    public void delete(Long id) {

        studentRepo.deleteById(id);
    }

    public StudentDto get(long id) {
        return studentRepo.findById(id).get();
    }
}
