package com.mapsa.StudentRegisteration.Controller;

import com.mapsa.StudentRegisteration.Model.StudentDto;
import com.mapsa.StudentRegisteration.Service.FileUploadUtil;
import com.mapsa.StudentRegisteration.Service.StudentService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.io.IOException;
import java.util.Optional;

@Controller
//@RequestMapping("/edit")
@RequiredArgsConstructor(onConstructor_ = @Autowired)
public class EditController {

    private final StudentService studentService;

    @GetMapping("/edit/{id}")
    public ModelAndView showUpdateForm(@PathVariable(name = "id") long id) {
        ModelAndView mav = new ModelAndView("update-student");

        StudentDto studentDto = studentService.get(id);
        mav.addObject("studentDto", studentDto);

        return mav;
    }

    @PostMapping("/update/{id}")
    public String updateStudent(@PathVariable("id") long id, @Valid StudentDto studentDto,
                                BindingResult result, Model model,
                                @RequestParam("image") MultipartFile multipartFile)
            throws IOException {

        String fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
        studentDto.setPhotos(fileName);

        //save (everything from) studentdto's fields ; info and photo
        StudentDto savedStudent = studentService.save(studentDto);

        String uploadDir = "student-photos/" + savedStudent.getId();

        FileUploadUtil.saveFile(uploadDir, fileName, multipartFile);

        //studentService.save(studentDto);
        model.addAttribute("studentDtoList", studentService.listOfStudent());

        if (result.hasErrors()) {
            studentDto.setId(id);
            return "update-student";
        }

        return "ListOfStudent";
    }


    @GetMapping("/delete/{id}")
    public String deleteStudent(@PathVariable("id") long id,Model model ) {

        studentService.delete(id);
        model.addAttribute("studentDtoList", studentService.listOfStudent());

        return "ListOfStudent";

    }
}
