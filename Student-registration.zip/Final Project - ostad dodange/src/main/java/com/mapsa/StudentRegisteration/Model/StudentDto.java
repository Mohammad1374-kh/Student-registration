package com.mapsa.StudentRegisteration.Model;


import com.mapsa.StudentRegisteration.config.Annotations.SidValidation;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.Date;

@Entity
@Table(name="Student")

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class StudentDto {
    @Column(name="id")
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Size(min = 2,max = 30,message = "firstname must be between 2 to 30 characters")
    @NotBlank(message = "firstname is mandatory!")
    @Column(name="firstname")
    private String firstName;

    @Size(min = 2,max = 30,message = "lastName must be between 2 to 30 characters")
    @NotBlank(message = "lastName is mandatory!")
    @Column(name="lastName")
    private String lastName;

    @Email
    @NotBlank(message = "email is mandatory!")
    @Column(name="email")
    private String email;

    @SidValidation
    @NotBlank(message = "Student Id is mandatory!")
    @Column(name="sid")
    private String sid;


    @Column(nullable = true , length = 64)
    private String photos;

    @Column(name="gender")
    @NotBlank(message = "gender is mandatory!")
    private String gender;

    @NotNull
    @DateTimeFormat(pattern = "yyyy-mm-dd")
    @Column(name="entranceDate")
    private Date entranceDate;

    @Transient
    public String getPhotosImagePath() {
        if (photos == null || id == null) return null;

        return "/student-photos/" + id + "/" + photos;
    }



//    @Column(name="gender")
//    private boolean gender;
//    @Column(name="note")
//    private String note;
//    @Column(name="married")
//    private boolean married;
//    @Column(name="birthday")
//    private Date birthday;


}
